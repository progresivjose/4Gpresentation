require 'test_helper'

class FotosHelperTest < ActionView::TestCase
end
