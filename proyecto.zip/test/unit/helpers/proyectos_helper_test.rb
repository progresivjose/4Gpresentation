require 'test_helper'

class ProyectosHelperTest < ActionView::TestCase
end
