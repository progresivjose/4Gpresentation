require 'test_helper'

class DiscosHelperTest < ActionView::TestCase
end
